import re


def substitution_function(sub_text):
    text = re.sub(r'\.', '', sub_text)
    text = re.sub(r',', '.', text)
    return text


def invoicePeriod(text, contract):
    if contract == 'CONVENTIONAL':
        measurement_end_begin = re.search(r'(?<!Roteiro de )[lL]eitura.*?(\b\d{2}\/\d{2}\/\d{4}\b)\s*?(\b\d{2}\/\d{2}\/\d{4}\b)', text, re.S)
        aux_position = measurement_end_begin.span()[1]
        return measurement_end_begin[2], measurement_end_begin[1], aux_position
    else:
        measurement_begin, measurement_end = re.findall(r'(?<!Roteiro de )[lL]eitura.*?(\b\d{2}\/\d{2}\/\d{4}\b)', text)[0:2]
        aux_position = 0
        return measurement_begin, measurement_end, aux_position


def ConsumptionHistoryElectricity(text, measurement_unit, contract):
    if measurement_unit == 'kWh':
        Wh_multiplier = 1000
    elif measurement_unit == 'MWh':
        Wh_multiplier = 1000000
    elif measurement_unit == 'Wh':
        Wh_multiplier = 1
    if contract != 'CONVENTIONAL':
        textAux = re.search(r'.+?Demanda ?\w*(?: \w+ \w+)? - \[[km]W\]', text, re.I | re.S)[0]
        Consumption_list = re.findall(r'\b(?:(\d{4}) )?([A-Z]{3})[ \t]+[0l\. ]+(\d+(?:,\d{2})?) +\d{2}\b', textAux, re.I)
        Consumption_values = []
        Consumption_History = {}
        Consumption_History_ForaPonta = {}
        Consumption_History_Ponta = {}
        for i in range(0, len(Consumption_list)):
            if len(Consumption_list[i][0]) == 4:
                year = Consumption_list[i][0]
            Consumption_values.append(re.sub(r',', '.', Consumption_list[i][2]))
            if i%2 != 0:
                if year not in Consumption_History:
                    Consumption_History[year] = {}
                    Consumption_History_ForaPonta[year] = {}
                    Consumption_History_Ponta[year] = {}
                Consumption_History[year][Consumption_list[i][1]] = (float(Consumption_values[i]) + float(Consumption_values[i - 1]))*Wh_multiplier
                Consumption_History_ForaPonta[year][Consumption_list[i][1]] = (float(Consumption_values[i]))*Wh_multiplier
                Consumption_History_Ponta[year][Consumption_list[i][1]] = (float(Consumption_values[i - 1]))*Wh_multiplier
    else:
        textAux = re.search(r'.+?para consulta dos indicadores acesse nosso site www\.', text, re.S | re.I)[0]
        Comsumption_list = re.findall(r'\b(?:(\d{4}) )?([A-Z]{3})[ \t]+[0l\. ]+(\d+(?:,\d{2})?) +\d{2}\b', textAux)
        Consumption_History = {}
        for i in range(0, len(Comsumption_list)):
            if len(Comsumption_list[i][0]) == 4:
                year = Comsumption_list[i][0]
            if year not in Consumption_History:
                Consumption_History[year] = {}
            Consumption_History[year][Comsumption_list[i][1]] = (float(re.sub(r',', '.', Comsumption_list[i][2])))*Wh_multiplier
        Consumption_History_ForaPonta = None
        Consumption_History_Ponta = None
        
    return Consumption_History, Consumption_History_Ponta, Consumption_History_ForaPonta


def DemandHistoryElectricity(text, measurement_unit):
        if measurement_unit == 'kWh':
            Wh_multiplier = 1000
        elif measurement_unit == 'MWh':
            Wh_multiplier = 1000000
        elif measurement_unit == 'Wh':
            Wh_multiplier = 1
        textAux = re.search(r'Demanda ?\w*(?: \w+ \w+)? - \[[km]W\].+', text, re.I | re.S)[0]
        textAux2 = re.search(r'.+?Consumo ?\w*(?: \w+ \w+)? - \[[km]W\]', textAux, re.I | re.S) #evitar repetição
        if textAux2 != None:
            textAux = textAux2[0]
        
        if re.search(r'Demanda Fora de Ponta - \[[km]W\].+', textAux, re.I | re.S) != None:
            Demand_list = re.findall(r'\b(?:(\d{4}) )?([A-Z]{3})[ \t]+[0l\. ]+(\d+(?:,\d{2})?) +\d{2}\b', textAux, re.I)
            Demand_values = []
            Demand_History = None
            Demand_History_ForaPonta = {}
            Demand_History_Ponta = {}
            for i in range(0, len(Demand_list)):
                if len(Demand_list[i][0]) == 4:
                    year = Demand_list[i][0]
                Demand_values.append(re.sub(r',', '.', Demand_list[i][2]))
                if i%2 != 0:
                    if year not in Demand_History_Ponta:
                        Demand_History_ForaPonta[year] = {}
                        Demand_History_Ponta[year] = {}
                    Demand_History_ForaPonta[year][Demand_list[i][1]] = (float(Demand_values[i]))*Wh_multiplier
                    Demand_History_Ponta[year][Demand_list[i][1]] = (float(Demand_values[i - 1]))*Wh_multiplier
        else:
            Demand_list = re.findall(r'\b(?:(\d{4}) )?([A-Z]{3})[ \t]+[0l\. ]+(\d+(?:,\d{2})?) +\d{2}\b', textAux, re.I)
            Demand_History = {}
            for i in range(0, len(Demand_list)):
                if len(Demand_list[i][0]) == 4:
                    year = Demand_list[i][0]
                if year not in Demand_History:
                    Demand_History[year] = {}
                Demand_History[year][Demand_list[i][1]] = (float(re.sub(r',', '.', Demand_list[i][2])))*Wh_multiplier
            Demand_History_ForaPonta = None
            Demand_History_Ponta = None
        return Demand_History, Demand_History_Ponta, Demand_History_ForaPonta
            
def Demand(text):
    aux = re.search(r'[úu]nica +?([\d,\.]*) +?[uú]nico.*?\n *ponta +?([\d,\.]*) +?ponta.*?\n *fora ?ponta +?([\d,\.]*) +?fora ?ponta', text, re.I)
    unico, ponta, fponta = aux[1], aux[2], aux[3]
    return unico, ponta, fponta


def unit(text, pos, contract):
    if contract != 'CONVENTIONAL':
        measurement_unit = re.search(r'Consumo Ponta - \[([mk]Wh)\]', text, re.I)[1]
    else:
        textAux = text[pos:]
        measurement_unit = re.search(r'\[([mk]Wh)\]', textAux, re.I)[1]
    return measurement_unit


def contract(text):    
    #contract_number = re.search(r'[cC]onta [cC]ontrato.*?(\d+)', text)[1]
    aux = re.search(r'  classifica[cç][aã]o:?(.+)', text, re.I)[1]
    consumer_entity_type = re.search(r'p[uú]blico ((federal)|(estadual)|(municipal))', aux, re.I)
    if consumer_entity_type == None:
        consumer_entity_type = re.search(r'(residencial)|(comercial)', aux, re.I)[0]
    else:
        consumer_entity_type = consumer_entity_type[0]
    consumer_group = re.search(r'(A\d)|(B\d)|(A3a)|(AS)', aux)[0]
    if re.search(r'verde', aux, re.I) != None:
        contract = 'HORO_SAZIONAL_GREEN'
    if re.search(r'azul', aux, re.I) != None:
        contract = 'HORO_SAZIONAL_BLUE'
    if re.search(r'convencional', aux, re.I) != None:
        contract = 'CONVENTIONAL'
    if re.search(r'livre', aux, re.I) != None:
        contract = 'LIVRE'
    if re.search(r'branco', aux, re.I) != None:
        contract = 'HORO_SAZIONAL_WHITE'
    return consumer_entity_type, contract, consumer_group


def InvoiceMetaData(text):
    try:
        Pn_CN_DT_TV = re.findall(r'(\d+) +(\d+) +[A-Z]{3}\/\d{4} +(\d{2}\/\d{2}\/\d{4}\b) +(\d{1,3}(?:\.\d{3})?(?:\.\d{3})?,\d{2}\b|\*+|-+)', text, re.S)[0]
        aux_for_details = False
    except IndexError:
        Pn_CN_DT_TV = re.search(r'(\d+) +\w+ +[A-Z]{3}\/\d{4} +(\d{2}\/\d{2}\/\d{4}\b) +(\d{1,3}(?:\.\d{3})?(?:\.\d{3})?,\d{2}\b|\*+|-+)', text, re.S)
        aux_for_details = True
        aux1_1 = re.findall(r'www\..*?\.br.*', text)
        aux1_2 = re.search(r'\b\d+\b', aux1_1[0])
        Pn_CN_DT_TV = Pn_CN_DT_TV[1], aux1_2[0], Pn_CN_DT_TV[2], Pn_CN_DT_TV[3]
    personal_code, Measurer_Code, due_date, total_value = Pn_CN_DT_TV[0], Pn_CN_DT_TV[1], Pn_CN_DT_TV[2], Pn_CN_DT_TV[3]
    total_value = substitution_function(total_value)
    emission_date = re.search(r'Emissão:? (\d{2}\/\d{2}\/\d{4})', text, re.I)[1]
    barcode_aux = re.search(r'(\d{12,14} ){3}\d{12,14}', text)
    if barcode_aux == None:
        barcode_aux2 = re.search(r'\d{5}\.\d{5} +\d{5}\.\d{6} +\d{5}\.\d{6} +\d +\d{14}', text)
        if barcode_aux2 == None:
            barcode = ''
        else:
            barcode = barcode_aux2[0]
    else:
        barcode = barcode_aux[0]
    return personal_code, Measurer_Code, due_date, emission_date, total_value, barcode, aux_for_details


def Consumer(text):
    textAux = re.search(r'\n[\S ]+((CNPJ)|(CPF)|(Classifica[cç][aã]o)).+', text, re.I | re.S | re.M)[0]
    aux = re.findall(r'^ *((?:[\S] {0,2})+\S+)', textAux, re.M)
    if re.search(r'\d{5}-\d{3}', aux[3]) == None:
        aux.insert(2, 0)
    registry = re.search(r'(?:Inscri[cç][aã]o Estadual:?|Insc.Est:?) (\S+)', textAux, re.I)
    cep = re.search(r'\d{5}-\d{3}', aux[3])[0]
    city = re.sub(r'\d{5}-\d{3} ?', '', aux[3])
    name, adress = aux[0], aux[1]
    CNPJ_CPF = re.search(r'CNPJ:? ?(\d\d(?:\.\d{3}){2}\/\d{4}-\d\d)', text)
    CNPJ_CPF_Type = 'CNPJ'
    if CNPJ_CPF == None:
        CNPJ_CPF = re.search(r'CPF:? ?(\d{3}\.\d{3}\.\d{3}-\d\d)', text)
        CNPJ_CPF_Type = 'CPF'
    return name, adress, city, cep, registry, CNPJ_CPF[1], CNPJ_CPF_Type


def details(text, aux_details):
    operations = []
    if aux_details:
        aux_for_position = re.finditer(r'(\d+) +\w+ +[A-Z]{3}\/\d{4} +(\d{2}\/\d{2}\/\d{4}\b) +(\d{1,3}(?:\.\d{3})?(?:\.\d{3})?,\d{2}\b|\*+|-+)', text, re.S)
    else:
        aux_for_position = re.finditer(r'(\d+) +(\d+) +[A-Z]{3}\/\d{4} +(\d{2}\/\d{2}\/\d{4}\b) +(\d{1,3}(?:\.\d{3})?(?:\.\d{3})?,\d{2}\b|\*+|-+)', text, re.S)
    for i in aux_for_position:
        detail_text_beginning = text[i.span()[1]:]
        end_position = re.search(r'(Total Consolidado)|(Total a Pagar)|(Autentica[cç][aã]o Mec[aâ]nica no Verso)', detail_text_beginning, re.I)
        if end_position == None:
            continue
        text_details = detail_text_beginning[:end_position.span()[1]]
        disc_operations = re.findall(r'\n *?(\d{4}) +?((?:\S+ )*\S+)   .*?\b(\d{1,3}(?:\.\d{3})*,\d{2})\b', text_details)
        for j in disc_operations:
            operations.append(j)
    for i in operations:
        while operations.count(i) > 1:
            operations.reverse()
            operations.remove(i)
            operations.reverse()
    monetary_flag = {}
    for i in operations:
        if re.search(r'(Adicional (?:de band|band)\w*(?: \w+)+)', i[1], re.I) != None:
            monetary_flag[re.search(r'(vermelha|amarela)(.*ponta)?', i[1], re.I)[0]] = substitution_function(i[2])
    return operations, monetary_flag


def main(diret):
    arquivo = open(diret, 'r', encoding = 'UTF-8')
    texto = arquivo.read()
    consumer_entity_type, contract_classification, consumer_group = contract(texto)
    personal_code, Measurer_Code, due_date, emission_date, total_value, barcode, aux_details  = InvoiceMetaData(texto)
    name, adress, city, cep, registry, CNPJ_CPF, CNPJ_CPF_Type  = Consumer(texto)
    measurement_begin, measurement_end, aux_position = invoicePeriod(texto, contract_classification)
    measurement_unit = unit(texto, aux_position, contract_classification)
    Consumption_History, Consumption_History_Ponta, Consumption_History_ForaPonta = ConsumptionHistoryElectricity(texto, measurement_unit, contract_classification)
    operations, monetary_flags = details(texto, aux_details)
    if contract_classification != 'CONVENTIONAL' and contract_classification != 'HORO_SAZIONAL_WHITE':
        single_demand, ponta_demand, fponta_demand = Demand(texto)
    if Consumption_History != None:
        actual_year = list(Consumption_History.keys())[0]
        actual_month = list(Consumption_History.get(actual_year).keys())[0]
        ConsumptionActualElectricity = Consumption_History.get(actual_year).get(actual_month)
        if contract_classification != 'CONVENTIONAL':
            ConsumptionActualElectricityPonta = Consumption_History_Ponta.get(actual_year).get(actual_month)
            ConsumptionActualElectricityForaPonta = Consumption_History_ForaPonta.get(actual_year).get(actual_month)

    info_data_string = f'''Invoice:
        emission_date: {emission_date} 
        meter_id: {Measurer_Code}
        measurement_period: {measurement_begin} - {measurement_end}
        ref_month: {list(Consumption_History.get(list(Consumption_History.keys())[0]).keys())[0]}
Company:
        name: CPFL Energia
        CNPJ: 33.050.196/0001-88
        company_state_registry: 244.163.955.115
        adress: Rua Jorge de Figueiredo Correa 1632, Campinas - SP
Contract:
        contract_category: {contract_classification}
        consumer_number (PN): {personal_code}
Payment:
        Invoice_total_value [R$]: {total_value}
        barcode: {barcode}
        due_date: {due_date}
Consumer:
        name: {name}
        document ({CNPJ_CPF_Type}): {CNPJ_CPF}
        consumer_subgroup: {consumer_group}
        consumer_belongs: {consumer_entity_type}
        adress: {adress}, {city}
        CEP: {cep}\n'''
    
    if registry != None:
        info_data_string += f'        consumer_state_registry: {registry[1]}\n'

    info_data_string += f'''Actual_consumption: {ConsumptionActualElectricity:.2f} Wh\n'''
    if contract_classification != 'CONVENTIONAL':
        info_data_string += f'''Actual_consumption_Fora_de_Ponta: {ConsumptionActualElectricityForaPonta} Wh
Actual_consumption_Ponta: {ConsumptionActualElectricityPonta} Wh\n'''
    info_data_string += '''Consumption_history:\n'''
    
    for year in Consumption_History:
        for month in Consumption_History[year]:
            info_data_string += f'        {year} - {month}: {Consumption_History[year][month]:.2f} Wh\n'
    
    if contract_classification != 'CONVENTIONAL':
        info_data_string += f'''Consumption_history_Fora_de_Ponta:\n'''
        for year in Consumption_History_ForaPonta:
            for month in Consumption_History_ForaPonta[year]:
                info_data_string += f'        {year} - {month}: {Consumption_History_ForaPonta[year][month]:.2f} Wh\n'

        info_data_string += f'''Consumption_history_Ponta:\n'''
        for year in Consumption_History_Ponta:
            for month in Consumption_History_Ponta[year]:
                info_data_string += f'        {year} - {month}: {Consumption_History_Ponta[year][month]:.2f} Wh\n'

    if contract_classification != 'CONVENTIONAL' and contract_classification != 'HORO_SAZIONAL_WHITE':
        Demand_History, Demand_History_Ponta, Demand_History_ForaPonta = DemandHistoryElectricity(texto, measurement_unit)
        if len(single_demand) != 0:
            single_demand = substitution_function(single_demand)
            single_demand = float(single_demand)*1000
            info_data_string += f'Contracted_demand: {single_demand:.2f} W\n'
        elif len(ponta_demand) != 0 and len(fponta_demand) != 0:
            ponta_demand, fponta_demand = substitution_function(ponta_demand), substitution_function(fponta_demand)
            ponta_demand, fponta_demand = float(ponta_demand)*1000, float(fponta_demand)*1000
            info_data_string += f'Contracted_demand_ponta: {ponta_demand:.2f} W\nContracted_demand_fponta: {fponta_demand:.2f} W\n'

        if Demand_History != None:
            DemandActualElectricity = Demand_History.get(actual_year).get(actual_month)
            info_data_string += f'''Actual_Demand: {DemandActualElectricity:.2f}\n'''
            info_data_string += f'''Demand_history:\n'''
            for year in Demand_History:
                for month in Demand_History[year]:
                    info_data_string += f'        {year} - {month}: {Demand_History[year][month]:.2f} W\n'
        else:
            DemandActualElectricityPonta = Demand_History_Ponta.get(actual_year).get(actual_month)
            info_data_string += f'''Actual_Demand_Ponta: {DemandActualElectricityPonta:.2f} W\n'''
            info_data_string += f'''Demand_history_Ponta:\n'''
            for year in Demand_History_Ponta:
                for month in Demand_History_Ponta[year]:
                    info_data_string += f'        {year} - {month}: {Demand_History_Ponta[year][month]:.2f} W\n'
            DemandActualElectricityForaPonta = Demand_History_ForaPonta.get(actual_year).get(actual_month)
            info_data_string += f'''Actual_Demand_Fora_de Ponta: {DemandActualElectricityForaPonta:.2f} W\n'''
            info_data_string += f'''Demand_history_Fora_de_Ponta:\n'''
            for year in Demand_History_ForaPonta:
                for month in Demand_History_ForaPonta[year]:
                    info_data_string += f'        {year} - {month}: {Demand_History_ForaPonta[year][month]:.2f} W\n'

    info_data_string += 'Monetary_flags:\n'
    
    for i in monetary_flags:
        info_data_string += f'        flag: {i}, value [R$]: {monetary_flags[i]}\n'

    info_data_string += 'Operations:\n'

    for i in operations:
        info_data_string += f'        {i[0]} ({i[1]}) [R$]: {i[2]}\n'

    arquivo.close()    
    
    return info_data_string


if __name__ == '__main__':
    diret = input('escreva o diretorio do arquivo:\n')
    data = main(diret)
    print(data)