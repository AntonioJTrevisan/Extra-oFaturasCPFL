
import base64
import os
import time
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


os.chdir(os.path.dirname(__file__))

SCOPES = ["https://mail.google.com/"]


creds = None
# The file token.json stores the user's access and refresh tokens, and is
# created automatically when the authorization flow completes for the first
# time.
if os.path.exists("token.json"):
    creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    # If there are no (valid) credentials available, let the user log in.
if not creds or not creds.valid:
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    else:
        flow = InstalledAppFlow.from_client_secrets_file(
            "credentials.json", SCOPES
        )
        creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
    with open("token.json", "w") as token:
        token.write(creds.to_json())
    
try:
    # Call the Gmail API
    service = build("gmail", "v1", credentials=creds)
    print('gmail', 'v1', 'service created successfully')
except HttpError as error:
    # TODO(developer) - Handle errors from gmail API.
    print(f"An error occurred: {error}")


def search_emails(query, labels=None):
    next_page_token = None
    
    message_response = service.users().messages().list(
        userId='me',
        labelIds=labels,
        includeSpamTrash=False,
        q=query,
        maxResults=500
    ).execute()
    email_messages = message_response.get('messages')
    next_page_token = message_response.get('nextPageToken')

    while next_page_token:
        message_response = service.users().messages().list(
            userId='me',
            labelIds=labels,
            q=query,
            maxResults=500,
            includeSpamTrash=False,
            pageToken=next_page_token
        ).execute()
        email_messages.extend(message_response['messages'])
        next_page_token = message_response.get('nextPageToken')
        print('Page Token: {0}'.format(next_page_token))
        time.sleep(0.5)
    return email_messages


def get_attachment_info(result):
    print(result)
    print(result.get('id'))
    thread = service.users().threads().get(
        userId='me',
        id=result.get('threadId')
    ).execute()
    print(thread)
    threadMessages = thread.get('messages')
    print(threadMessages)
    for Tmessage in threadMessages:
        id = Tmessage.get('id')
    message = service.users().messages().get(
        userId='me',
        id=id,
        format='full'
    ).execute()
    return_path_email = get_return_path_email(message)
    attachmentId = {}
    for part in message.get('payload').get('parts'):
        if part.get('mimeType') == 'application/pdf':
            filename = part.get('filename')
            attachmentId[filename] = part.get('body').get('attachmentId')
    attachment = {}
    for file_name in attachmentId:
        try:
            attachment[file_name] = (service.users().messages().attachments().get(
                userId='me',
                messageId=result.get('id'),
                id=attachmentId.get(file_name)
            ))
        except Exception:
            attachment[file_name] = None       
    return attachment, return_path_email


def get_return_path_email(message):
    return_path = None
    for header in message.get('payload').get('headers'):
        if header.get('name') == 'Return-Path':
            return_path = header.get('value')
            break
    if return_path != None:
        return return_path[1: -1]
    for header in message.get('payload').get('headers'):
        if header.get('name') == 'From':
            from_name_and_email = header.get('value')
            from_email = re.search(r'\".+?\" ?<(.+)>', from_name_and_email)[1]
            return from_email

    
        
        
def download_attachments(filename, attachment):
    content = base64.urlsafe_b64decode(attachment.execute().get('data').encode('UTF-8'))
    with open(os.path.join(os.getcwd(), filename), 'wb') as _f:
        _f.write(content)
    return None


def send_email(to_email, message_string, subject):
    emailMessage = message_string
    mimeMessage = MIMEMultipart()
    mimeMessage['to'] = to_email
    mimeMessage['subject'] = subject
    mimeMessage.attach(MIMEText(emailMessage, 'plain'))
    raw_string = base64.urlsafe_b64encode(mimeMessage.as_bytes()).decode()
    message = service.users().messages().send(userId='me', body={'raw': raw_string}).execute()
    return None


def move_to_trash(result):
    thread = service.users().threads().get(
        userId='me',
        id=result.get('threadId')
    ).execute()
    threadMessages = thread.get('messages')
    for Tmessage in threadMessages:
        messageId = Tmessage.get('id')
    message = service.users().messages().get(
        userId='me',
        id=messageId,
        format='full'
    ).execute()
    service.users().messages().trash(
        userId='me',
        id=messageId
    ).execute()
    return None


        

