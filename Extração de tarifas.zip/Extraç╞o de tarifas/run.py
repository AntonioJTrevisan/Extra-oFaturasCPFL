import os
import time
import ghostscript
import extractor
import email_interaction as em


def main():
    query_string = "subject:_DATA_EXTRACT_CPFL_"
    email_results = em.search_emails(query_string)
    if email_results:
        for result in email_results:
            attachment = None
            download = False
            try:
                attachment, return_path_email = em.get_attachment_info(result)
            except Exception as Error:
                print(f'Failed to get email info: {Error}')
            for filename in attachment:
                error = False
                if attachment.get(filename):
                    print(filename)
                    try:
                        em.download_attachments('PDFArchive.pdf', attachment.get(filename))
                        download = True
                    except Exception as Error:
                        print(f'Could not download {filename}: {Error}')
                        error = True
                    if not error:
                        args = b"""-dNOSAFER -sDEVICE=txtwrite -o TXTArchive.txt PDFArchive.pdf""".split()
                        try:
                            ghostscript.Ghostscript(*args)
                        except Exception as Error:
                            print(f'{filename} failed at Ghostscript: {Error}')
                            error = True
                    if not error:
                        try:
                            info_data_string = extractor.main(os.path.join(os.getcwd(), 'TXTArchive.txt'))
                        except Exception as Error:
                            print(f'Failed on extract data from {filename}: {Error}')
                            error = True
                    if not error:
                        try:
                            em.send_email(return_path_email, info_data_string, filename)
                            print(f'{filename} email successfully sent')
                        except Exception as Error:
                            print(f'{filename} failed on sending email: {Error}')
                    if download:
                        try:
                            os.remove(os.path.join(os.getcwd(), 'PDFArchive.pdf'))
                            os.remove(os.path.join(os.getcwd(), 'TXTArchive.txt'))
                        except Exception as Error:
                            print(f'Could not remove {filename}: {Error}')   
            print('trash')       
            em.move_to_trash(result)
            print('sent to trash')
    return None


if __name__ == '__main__':
    os.chdir(os.path.dirname(__file__))
    while True:
        try:
            main()
        except Exception as Error:
            print(Error)
        time.sleep(1)